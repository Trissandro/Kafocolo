-- =========================================================
--  NOVAS TABELAS (executar uma vez na BD tv_corporativa)
--  Colocar conteudo no fim do ficheiro: server/database/schema.sql
--  OU executar diretamente no MySQL.
-- =========================================================
USE tv_corporativa;

-- ---------- Sintonias de Radio (links) ----------
CREATE TABLE IF NOT EXISTS radio_stations (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  stream_url  VARCHAR(500) NOT NULL,   -- URL do stream de audio (mp3/aac/m3u8)
  genre       VARCHAR(80),
  logo_url    VARCHAR(500),
  created_by  INT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ---------- Sintonias de Canais de TV abertos (links) ----------
CREATE TABLE IF NOT EXISTS tv_channels (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  stream_url  VARCHAR(500) NOT NULL,   -- URL do stream de video (m3u8/mp4/youtube)
  category    VARCHAR(80),
  logo_url    VARCHAR(500),
  created_by  INT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ---------- Dados de exemplo ----------
INSERT INTO radio_stations (name, stream_url, genre) VALUES
  ('Radio Exemplo FM', 'https://stream.example.com/radio.mp3', 'Variados'),
  ('Jazz Corporate',   'https://stream.example.com/jazz.aac',  'Jazz');

INSERT INTO tv_channels (name, stream_url, category) VALUES
  ('Canal Noticias 24h', 'https://stream.example.com/news.m3u8', 'Noticias'),
  ('Canal Eventos',      'https://stream.example.com/events.m3u8','Eventos');
