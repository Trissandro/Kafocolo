# Guia: Adicionar as 5 novas funcionalidades ao projeto Grupo 23

> Cada ficheiro abaixo indica EXATAMENTE onde colocar no teu projeto inicial.
> "SUBSTITUIR" = apagar o conteudo antigo e colar o novo.
> "NOVO" = criar o ficheiro nesse caminho.
> "ACRESCENTAR" = colar no fim do ficheiro existente.

---
## PASSO 1 - Base de dados (uma vez)
- `01_DATABASE/novas_tabelas.sql`
  -> Cola o conteudo no FIM de `server/database/schema.sql`
     e volta a correr `npm run migrate`,
     OU corre o SQL diretamente no MySQL.

---
## PASSO 2 - Servidor (Node.js)
| Ficheiro deste pacote | Onde colocar no projeto | Acao |
|---|---|---|
| 02_SERVER/src/controllers/authController.js   | server/src/controllers/authController.js   | SUBSTITUIR |
| 02_SERVER/src/controllers/stationsController.js | server/src/controllers/stationsController.js | NOVO |
| 02_SERVER/src/routes/authRoutes.js            | server/src/routes/authRoutes.js            | SUBSTITUIR |
| 02_SERVER/src/routes/stationsRoutes.js        | server/src/routes/stationsRoutes.js        | NOVO |
| 02_SERVER/src/routes/mediaRoutes.js           | server/src/routes/mediaRoutes.js           | SUBSTITUIR |
| 02_SERVER/src/index.js                        | server/src/index.js                        | SUBSTITUIR |

---
## PASSO 3 - Cliente (React)
| Ficheiro deste pacote | Onde colocar no projeto | Acao |
|---|---|---|
| 03_CLIENT/src/components/Preview.jsx   | client/src/components/Preview.jsx   | NOVO |
| 03_CLIENT/src/components/MediaCard.jsx | client/src/components/MediaCard.jsx | SUBSTITUIR |
| 03_CLIENT/src/components/Navbar.jsx    | client/src/components/Navbar.jsx    | SUBSTITUIR |
| 03_CLIENT/src/pages/Profile.jsx        | client/src/pages/Profile.jsx        | NOVO |
| 03_CLIENT/src/pages/CreateUser.jsx     | client/src/pages/CreateUser.jsx     | NOVO |
| 03_CLIENT/src/pages/Radio.jsx          | client/src/pages/Radio.jsx          | NOVO |
| 03_CLIENT/src/pages/TV.jsx             | client/src/pages/TV.jsx             | NOVO |
| 03_CLIENT/src/App.jsx                  | client/src/App.jsx                  | SUBSTITUIR |
| 03_CLIENT/src/styles_ACRESCENTAR.css   | client/src/styles.css               | ACRESCENTAR (colar no fim) |

---
## PASSO 4 - Reiniciar
1. Servidor: parar e correr `npm run dev` outra vez.
2. Cliente: `npm run dev`.

## Resumo das funcionalidades adicionadas
1. Alterar password -> menu "Perfil"
2. Criar utilizadores (so admin; clientes/viewer NAO fazem upload) -> menu "Criar Utilizador"
3. Pre-visualizacao do conteudo -> nos cartoes da pagina Inicio
4. Sintonias de Radio (links) -> menu "Radio"
5. Canais de TV abertos (links) -> menu "TV Aberta"
