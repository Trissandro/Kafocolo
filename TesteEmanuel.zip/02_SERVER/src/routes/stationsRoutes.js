import { Router } from 'express';
import { authRequired, requireRole } from '../middleware/auth.js';
import {
  listRadios, createRadio, deleteRadio,
  listTv, createTv, deleteTv
} from '../controllers/stationsController.js';

const router = Router();
// Radio
router.get('/radio', authRequired, listRadios);
router.post('/radio', authRequired, requireRole('admin'), createRadio);   // so admin cria
router.delete('/radio/:id', authRequired, requireRole('admin'), deleteRadio);
// TV
router.get('/tv', authRequired, listTv);
router.post('/tv', authRequired, requireRole('admin'), createTv);         // so admin cria
router.delete('/tv/:id', authRequired, requireRole('admin'), deleteTv);
export default router;
