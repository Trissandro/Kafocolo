import { Router } from 'express';
import { register, login, me, changePassword, createUser } from '../controllers/authController.js';
import { authRequired, requireRole } from '../middleware/auth.js';

const router = Router();
router.post('/register', register);
router.post('/login', login);
router.get('/me', authRequired, me);
router.post('/change-password', authRequired, changePassword);        // NOVO
router.post('/users', authRequired, requireRole('admin'), createUser); // NOVO (so admin cria users com role)
export default router;
