import { Router } from 'express';
import { upload } from '../config/multer.js';
import { authRequired, requireRole } from '../middleware/auth.js';
import {
  uploadMedia, listMedia, getMedia, deleteMedia, downloadMedia, streamMedia
} from '../controllers/mediaController.js';

const router = Router();
router.get('/', authRequired, listMedia);
router.get('/:id', authRequired, getMedia);
router.get('/:id/stream', streamMedia);             // streaming (tambem usado na previsualizacao)
router.get('/:id/download', authRequired, downloadMedia);
// >>> ALTERADO: upload e delete agora SO para 'admin' (clientes/viewers nao podem) <<<
router.post('/', authRequired, requireRole('admin'), upload.single('file'), uploadMedia);
router.delete('/:id', authRequired, requireRole('admin'), deleteMedia);
export default router;
