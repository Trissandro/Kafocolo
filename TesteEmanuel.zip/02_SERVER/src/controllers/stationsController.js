import pool from '../config/db.js';
import { logAction } from '../utils/logger.js';

// ---------- RADIO ----------
export async function listRadios(req, res) {
  const [rows] = await pool.query('SELECT * FROM radio_stations ORDER BY name');
  res.json(rows);
}
export async function createRadio(req, res) {
  const { name, stream_url, genre, logo_url } = req.body;
  if (!name || !stream_url) return res.status(400).json({ error: 'Nome e URL obrigatorios.' });
  const [r] = await pool.query(
    'INSERT INTO radio_stations (name, stream_url, genre, logo_url, created_by) VALUES (?,?,?,?,?)',
    [name, stream_url, genre || '', logo_url || '', req.user.id]
  );
  await logAction(req.user.id, 'CREATE_RADIO', name, req.ip);
  res.status(201).json({ id: r.insertId, name, stream_url, genre, logo_url });
}
export async function deleteRadio(req, res) {
  await pool.query('DELETE FROM radio_stations WHERE id = ?', [req.params.id]);
  await logAction(req.user.id, 'DELETE_RADIO', `#${req.params.id}`, req.ip);
  res.json({ ok: true });
}

// ---------- TV ----------
export async function listTv(req, res) {
  const [rows] = await pool.query('SELECT * FROM tv_channels ORDER BY name');
  res.json(rows);
}
export async function createTv(req, res) {
  const { name, stream_url, category, logo_url } = req.body;
  if (!name || !stream_url) return res.status(400).json({ error: 'Nome e URL obrigatorios.' });
  const [r] = await pool.query(
    'INSERT INTO tv_channels (name, stream_url, category, logo_url, created_by) VALUES (?,?,?,?,?)',
    [name, stream_url, category || '', logo_url || '', req.user.id]
  );
  await logAction(req.user.id, 'CREATE_TV', name, req.ip);
  res.status(201).json({ id: r.insertId, name, stream_url, category, logo_url });
}
export async function deleteTv(req, res) {
  await pool.query('DELETE FROM tv_channels WHERE id = ?', [req.params.id]);
  await logAction(req.user.id, 'DELETE_TV', `#${req.params.id}`, req.ip);
  res.json({ ok: true });
}
