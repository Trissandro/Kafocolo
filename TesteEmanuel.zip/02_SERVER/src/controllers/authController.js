import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../config/db.js';
import { logAction } from '../utils/logger.js';
import dotenv from 'dotenv';
dotenv.config();

// Registo publico -> cria SEMPRE como 'viewer' (cliente, sem upload)
export async function register(req, res) {
  const { name, email, password, department } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Campos obrigatorios em falta.' });
  try {
    const [exists] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (exists.length) return res.status(409).json({ error: 'Email ja registado.' });
    const hash = await bcrypt.hash(password, 10);
    const [r] = await pool.query(
      'INSERT INTO users (name, email, password_hash, role, department) VALUES (?,?,?,?,?)',
      [name, email, hash, 'viewer', department || 'Geral']
    );
    await logAction(r.insertId, 'REGISTER', email, req.ip);
    res.status(201).json({ id: r.insertId, name, email, role: 'viewer' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}

export async function login(req, res) {
  const { email, password } = req.body;
  try {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Credenciais invalidas.' });
    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Credenciais invalidas.' });
    const token = jwt.sign(
      { id: user.id, name: user.name, role: user.role },
      process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '8h' }
    );
    await logAction(user.id, 'LOGIN', email, req.ip);
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role, department: user.department }
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
}

export async function me(req, res) {
  const [rows] = await pool.query(
    'SELECT id, name, email, role, department FROM users WHERE id = ?', [req.user.id]);
  res.json(rows[0] || null);
}

// ===== NOVO: Alterar a propria password =====
export async function changePassword(req, res) {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword)
    return res.status(400).json({ error: 'Preencha a password atual e a nova.' });
  if (newPassword.length < 6)
    return res.status(400).json({ error: 'A nova password deve ter pelo menos 6 caracteres.' });
  try {
    const [rows] = await pool.query('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'Utilizador nao encontrado.' });
    const ok = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!ok) return res.status(401).json({ error: 'Password atual incorreta.' });
    const hash = await bcrypt.hash(newPassword, 10);
    await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, req.user.id]);
    await logAction(req.user.id, 'CHANGE_PASSWORD', '', req.ip);
    res.json({ ok: true, message: 'Password alterada com sucesso.' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}

// ===== NOVO: Admin cria novo utilizador (pode definir o role) =====
export async function createUser(req, res) {
  const { name, email, password, role, department } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Campos obrigatorios em falta.' });
  const validRole = ['admin', 'editor', 'viewer'].includes(role) ? role : 'viewer';
  try {
    const [exists] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (exists.length) return res.status(409).json({ error: 'Email ja registado.' });
    const hash = await bcrypt.hash(password, 10);
    const [r] = await pool.query(
      'INSERT INTO users (name, email, password_hash, role, department) VALUES (?,?,?,?,?)',
      [name, email, hash, validRole, department || 'Geral']
    );
    await logAction(req.user.id, 'CREATE_USER', `${email} (${validRole})`, req.ip);
    res.status(201).json({ id: r.insertId, name, email, role: validRole, department: department || 'Geral' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}
