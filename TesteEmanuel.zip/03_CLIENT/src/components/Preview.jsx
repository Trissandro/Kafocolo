// Pre-visualizacao rapida do conteudo (usada nos cartoes / modal)
export default function Preview({ media, height = 160 }) {
  const src = `/api/media/${media.id}/stream`;
  const style = { width: '100%', height, objectFit: 'cover', borderRadius: 8, background: '#000' };

  if (media.type === 'image')
    return <img src={src} alt={media.title} style={style} />;
  if (media.type === 'video')
    return <video src={src} style={style} muted preload="metadata"
      onMouseOver={e => e.target.play()} onMouseOut={e => { e.target.pause(); e.target.currentTime = 0; }} />;
  if (media.type === 'audio')
    return (
      <div style={{ ...style, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column' }}>
        <span style={{ fontSize: 40 }}>🎵</span>
        <audio src={src} controls style={{ width:'90%', marginTop:8 }} />
      </div>
    );
  return null;
}
