import { Link } from 'react-router-dom';
import Preview from './Preview.jsx';

const icon = { video: '🎬', audio: '🎵', image: '🖼️' };

export default function MediaCard({ m }) {
  return (
    <div className="card">
      {/* Pre-visualizacao do conteudo */}
      <div className="card-preview">
        <Preview media={m} height={150} />
      </div>
      <div className="card-body">
        <h3>{icon[m.type]} {m.title}</h3>
        <p className="muted">{m.channel_name || 'Sem canal'} · {m.codec}</p>
        <p className="muted small">👁 {m.views} · ⬇ {(m.compression_ratio||0)}% poupado</p>
        <Link to={`/media/${m.id}`} className="btn-small">Abrir ▶</Link>
      </div>
    </div>
  );
}
