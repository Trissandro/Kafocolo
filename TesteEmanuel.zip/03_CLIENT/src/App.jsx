import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Navbar from './components/Navbar.jsx';
import Login from './pages/Login.jsx';
import Home from './pages/Home.jsx';
import MediaDetail from './pages/MediaDetail.jsx';
import Upload from './pages/Upload.jsx';
import Admin from './pages/Admin.jsx';
import Profile from './pages/Profile.jsx';        // NOVO
import CreateUser from './pages/CreateUser.jsx';   // NOVO
import Radio from './pages/Radio.jsx';             // NOVO
import TV from './pages/TV.jsx';                   // NOVO

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="container">A carregar...</div>;
  return user ? children : <Navigate to="/login" />;
}

// Rota apenas para um determinado perfil
function RoleRoute({ role, children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="container">A carregar...</div>;
  if (!user) return <Navigate to="/login" />;
  return user.role === role ? children : <Navigate to="/" />;
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Protected><Home /></Protected>} />
        <Route path="/media/:id" element={<Protected><MediaDetail /></Protected>} />
        <Route path="/radio" element={<Protected><Radio /></Protected>} />
        <Route path="/tv" element={<Protected><TV /></Protected>} />
        <Route path="/perfil" element={<Protected><Profile /></Protected>} />
        {/* SO admin */}
        <Route path="/upload" element={<RoleRoute role="admin"><Upload /></RoleRoute>} />
        <Route path="/criar-utilizador" element={<RoleRoute role="admin"><CreateUser /></RoleRoute>} />
        <Route path="/admin" element={<Protected><Admin /></Protected>} />
      </Routes>
    </>
  );
}
