import { useState } from 'react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Profile() {
  const { user } = useAuth();
  const [form, setForm] = useState({ currentPassword:'', newPassword:'', confirm:'' });
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault(); setMsg(''); setErr('');
    if (form.newPassword !== form.confirm) return setErr('As novas passwords nao coincidem.');
    try {
      const r = await api.post('/auth/change-password', {
        currentPassword: form.currentPassword, newPassword: form.newPassword
      });
      setMsg(r.data.message || 'Password alterada!');
      setForm({ currentPassword:'', newPassword:'', confirm:'' });
    } catch (e) { setErr(e.response?.data?.error || 'Erro ao alterar password.'); }
  };

  return (
    <div className="container narrow">
      <h2>O Meu Perfil</h2>
      <p className="muted">{user.name} · {user.email} · {user.role}</p>

      <h3>Alterar Password</h3>
      {msg && <div className="info">{msg}</div>}
      {err && <div className="error">{err}</div>}
      <form onSubmit={submit}>
        <label>Password atual</label>
        <input type="password" value={form.currentPassword}
          onChange={e=>setForm({...form, currentPassword:e.target.value})} required />
        <label>Nova password</label>
        <input type="password" value={form.newPassword}
          onChange={e=>setForm({...form, newPassword:e.target.value})} required />
        <label>Confirmar nova password</label>
        <input type="password" value={form.confirm}
          onChange={e=>setForm({...form, confirm:e.target.value})} required />
        <button type="submit">Alterar Password</button>
      </form>
    </div>
  );
}
