import { useState } from 'react';
import api from '../api/client.js';

export default function CreateUser() {
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'viewer', department:'' });
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault(); setMsg(''); setErr('');
    try {
      const r = await api.post('/auth/users', form);
      setMsg(`Utilizador "${r.data.name}" criado como ${r.data.role}.`);
      setForm({ name:'', email:'', password:'', role:'viewer', department:'' });
    } catch (e) { setErr(e.response?.data?.error || 'Erro ao criar utilizador.'); }
  };

  return (
    <div className="container narrow">
      <h2>Criar Novo Utilizador</h2>
      <p className="muted">Apenas administradores. Os clientes (viewer) nao podem fazer upload.</p>
      {msg && <div className="info">{msg}</div>}
      {err && <div className="error">{err}</div>}
      <form onSubmit={submit}>
        <label>Nome</label>
        <input value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
        <label>Email</label>
        <input type="email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required />
        <label>Password</label>
        <input type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} required />
        <label>Perfil</label>
        <select value={form.role} onChange={e=>setForm({...form, role:e.target.value})}>
          <option value="viewer">Viewer (cliente - apenas consulta)</option>
          <option value="editor">Editor</option>
          <option value="admin">Admin</option>
        </select>
        <label>Departamento</label>
        <input value={form.department} onChange={e=>setForm({...form, department:e.target.value})} />
        <button type="submit">Criar Utilizador</button>
      </form>
    </div>
  );
}
