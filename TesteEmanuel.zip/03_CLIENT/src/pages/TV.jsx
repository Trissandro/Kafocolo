import { useEffect, useState } from 'react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function TV() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [watching, setWatching] = useState(null);
  const [form, setForm] = useState({ name:'', stream_url:'', category:'', logo_url:'' });

  const load = () => api.get('/stations/tv').then(r=>setList(r.data));
  useEffect(() => { load(); }, []);

  const add = async (e) => {
    e.preventDefault();
    await api.post('/stations/tv', form);
    setForm({ name:'', stream_url:'', category:'', logo_url:'' });
    load();
  };
  const remove = async (id) => { await api.delete(`/stations/tv/${id}`); load(); };

  const isYouTube = (u) => /youtube\.com|youtu\.be/.test(u);
  const ytEmbed = (u) => {
    const m = u.match(/(?:v=|youtu\.be\/|embed\/)([\w-]{11})/);
    return m ? `https://www.youtube.com/embed/${m[1]}?autoplay=1` : u;
  };

  return (
    <div className="container">
      <h2>📡 Canais de TV Abertos</h2>

      {watching && (
        <div className="tv-player">
          <div className="tv-head">
            <span>📺 A ver: <b>{watching.name}</b></span>
            <button onClick={()=>setWatching(null)}>✖ Fechar</button>
          </div>
          {isYouTube(watching.stream_url)
            ? <iframe title="tv" width="100%" height="420" src={ytEmbed(watching.stream_url)}
                frameBorder="0" allow="autoplay; encrypted-media" allowFullScreen />
            : <video src={watching.stream_url} controls autoPlay width="100%" style={{maxHeight:420, background:'#000'}} />}
        </div>
      )}

      <div className="grid">
        {list.map(t => (
          <div className="card" key={t.id}>
            <div className="card-icon">📺</div>
            <div className="card-body">
              <h3>{t.name}</h3>
              <p className="muted">{t.category}</p>
              <button className="btn-small" onClick={()=>setWatching(t)}>▶ Ver</button>
              <a className="btn-small" href={t.stream_url} target="_blank" rel="noreferrer">↗ Abrir link</a>
              {user.role==='admin' && <button className="btn-del" onClick={()=>remove(t.id)}>🗑</button>}
            </div>
          </div>
        ))}
      </div>

      {user.role === 'admin' && (
        <>
          <h3>Adicionar canal de TV</h3>
          <form onSubmit={add} className="inline-form">
            <input placeholder="Nome" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />
            <input placeholder="URL do stream (m3u8/mp4/YouTube)" value={form.stream_url} onChange={e=>setForm({...form,stream_url:e.target.value})} required />
            <input placeholder="Categoria" value={form.category} onChange={e=>setForm({...form,category:e.target.value})} />
            <button type="submit">Adicionar</button>
          </form>
        </>
      )}
    </div>
  );
}
