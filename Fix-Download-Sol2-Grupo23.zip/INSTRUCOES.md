# Correção do Download — SOLUÇÃO 2 (Grupo 23)

A Solução 2 mantém o `<a href>` e envia o token na query string `?token=...`.
O servidor passa a aceitar o token no header OU na query.

## Ficheiros a substituir

| # | Ficheiro do ZIP | Caminho no teu projeto | Ação |
|---|---|---|---|
| 1 | client/src/pages/MediaDetail.jsx | client/src/pages/MediaDetail.jsx | SUBSTITUIR |
| 2 | server/src/middleware/auth.js | server/src/middleware/auth.js | SUBSTITUIR |

> Se o teu auth.js tiver mais funções além de `authRequired` e `requireRole`,
> NÃO substituas o ficheiro inteiro — apenas acrescenta a linha:
>     if (!token && req.query.token) token = req.query.token;
> logo a seguir à linha que lê o token do header.

## Depois
1. Reinicia o servidor: cd server && npm run dev
2. Hard refresh no navegador: Ctrl + Shift + R
3. Clica em Download -> deve funcionar.

## Aviso
O token fica visível no URL (histórico/logs). Aceitável para projeto académico,
mas a Solução 1 (Axios + blob) é mais segura.
