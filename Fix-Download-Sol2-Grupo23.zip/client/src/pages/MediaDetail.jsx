import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/client.js';
import Player from '../components/Player.jsx';

const fmt = b => b > 1e6 ? (b/1e6).toFixed(2)+' MB' : (b/1024).toFixed(1)+' KB';

export default function MediaDetail() {
  const { id } = useParams();
  const [m, setM] = useState(null);

  useEffect(() => { api.get(`/media/${id}`).then(r=>setM(r.data)); }, [id]);
  if (!m) return <div className="container">A carregar...</div>;

  // SOLUCAO 2: passar o token JWT na query string do link
  const token = localStorage.getItem('token');
  const downloadUrl = `/api/media/${m.id}/download?token=${token}`;

  return (
    <div className="container">
      <h2>{m.title}</h2>
      <Player media={m} />
      <p>{m.description}</p>
      <a className="btn" href={downloadUrl}>⬇ Download</a>

      <h3>Relatório de Compressão</h3>
      <table className="report">
        <tbody>
          <tr><td>Codec</td><td>{m.codec}</td></tr>
          <tr><td>Tamanho original</td><td>{fmt(m.original_size)}</td></tr>
          <tr><td>Tamanho comprimido</td><td>{fmt(m.compressed_size)}</td></tr>
          <tr><td>Taxa de compressão</td><td>{m.compression_ratio}% poupado</td></tr>
          <tr><td>Tempo de processamento</td><td>{m.process_time_ms} ms</td></tr>
        </tbody>
      </table>
    </div>
  );
}
