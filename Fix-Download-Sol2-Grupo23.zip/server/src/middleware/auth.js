import jwt from 'jsonwebtoken';

export function authRequired(req, res, next) {
  // 1) tenta o cabecalho Authorization: Bearer <token>
  let token = req.headers.authorization?.split(' ')[1];

  // 2) SOLUCAO 2: se nao houver no header, aceita ?token=... na query
  //    (necessario para downloads via <a href>)
  if (!token && req.query.token) token = req.query.token;

  if (!token) return res.status(401).json({ error: 'Token não fornecido.' });

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Token inválido.' });
  }
}

// (mantem aqui as tuas outras funcoes, ex.: requireRole)
export function requireRole(role) {
  return (req, res, next) => {
    if (req.user?.role !== role) {
      return res.status(403).json({ error: 'Sem permissão.' });
    }
    next();
  };
}
