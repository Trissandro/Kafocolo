import React from "react";
import './Account.css';
import {Link} from "react-router-dom";
import { useState } from "react";


function Account(){
    const [valornome, setName] = useState("");
    const [visanome, setVisanome]=useState("");
      const Entradas = (event) => {
        event.preventDefault();
        alert(`Transferência efectuada com sucesso no valor de: ${valornome} para: ${visanome}`);
      }
return(
    <>
    <div id="lado">
                <Link to={'/Account'} id="simulacao">Simulação</Link>
                <Link to={'/Conversao'} id="Conversao">Conversão</Link>
                <Link to={'/Transferencia'} id="transferencia">Transferência</Link>
                <Link to={'/Taxas'} id="taxas">Taxas</Link>
    </div>
    <h2 id="saldo4">Saldo</h2>
    <p id="saldo3">2.000.000,00 kz</p>
    <div id="infop1"> 
    <h3 id="sim">Simulação</h3>
    <form onSubmit={Entradas}>
    <label id="moedas">Moeda</label>
    <input id="moedanome" placeholder="Ex.Kwanza Angolano" type="text"/>
    <label id="paras">Para</label>
    <input id="paranome" placeholder="Carteira Digital" type="text"/>
    <label id="valor">Valor</label>
    <input id="valornome" value={valornome} 
     onChange={(e)=>setName(e.target.value)} 
    placeholder="Ex.2.000" type="text"/>
    <label id="visa">Visa</label>
    <input id="visanome" value={visanome} 
     onChange={(e)=>setVisanome(e.target.value)}placeholder="Número do Cartão" type="number"/>
	<p id="conv1">Simule uma operação.</p>
    <button id="transferir" type="submit">Transferência</button>
    </form>
        </div>
    </>
);

}

export default Account;