import React from "react";
import './Conversao.css';
import { useState } from "react";

function Conversao(){
    const [valornome, setName] = useState("");
    const [valb, setB] = useState("");
    var visanome;
  const Entradas = (event) => {
    event.preventDefault();
    var i=555;
    visanome=valornome*i  
  setB(visanome);
}
    return(
        <>
        
        <div id="lado">
       <a id="simulacao" href="./Account.js">Simulação</a><br></br>
       <a id="conversao" href="./Conversao">Conversão</a><br></br>
       <a id="transferencia" href="./Transferencia">Transferência</a><br></br>
       <a id="taxas" href="./Taxas">Taxas</a>
    </div>
    <h2 id="saldo5">Saldo</h2>
    <h3 id="saldo6">2.000.000,00 kz</h3>
    <div id="infop2"> 
    <h3 id="conversa">Conversão</h3>
    <form onSubmit={Entradas}>
    <label id="moedainicial">Moeda Inicial</label>
    <label id="moedafinal">Moeda Final</label>
    <input id="moedanome" placeholder="Ex.Kwanza Angolano" type="text"/>
    <input id="paranome" placeholder="Carteira Digital" type="text"/>
    <input id="valornome" value={valornome} 
     onChange={(e)=>setName(e.target.value)} 
    placeholder="Ex.2.000" type="text"/>
    <label id="visa">Visa</label>
    <label id="aqui" onChange={Entradas}>{valb} KZ</label>
	<p id="conv2">A conversão está sujeita a uma taxa, ela depende do câmbio do dia.</p>
    <input id="transferir" type="submit" value="Converter"></input>
    </form>
        </div>
        </>
    );
}

export default Conversao;