import './corpo.css'
import imagem from './fun.png'

function Corpo(){

    return(
        <>
<div id="corpo">
<div id="imagem"> 
<img src={imagem} alt="Não pegou"></img>
</div>
</div>

<div id="corpo1">
<h2 id="DP">Moedas Populares</h2>

<ul id="cabecalhomoedas">
<li>Nome</li>
<li>Símbolo</li>
<li id="pa">Preço Anterior</li>
<li id="pa">Preço Actual</li>
<li>Variação</li>
</ul>
<ul id="nomesmoedas">
<li>Dollar</li>
<li>Euro</li>
<li>Kwanza</li>
<li>Real</li>
<li>Franco Suiço</li>
</ul>

<ul id="simbolomoedas">
<li>$</li>
<li>€</li>
<li>KZ</li>
<li>R$</li>
<li>FR</li>
</ul>

<ul id="precoanteriormoedas">
<li>1</li>
<li>0.98</li>
<li>507</li>
<li>5.34</li>
<li>0,94</li>
</ul>
<ul id="precoatualmoedas">
<li>1</li>
<li>0.94</li>
<li>539.86</li>
<li>5.29</li>
<li>0.92</li>
</ul>
<ul id="variacaomoedas">
<li>0</li>
<li>0.04</li>
<li>32.86</li>
<li>0.5</li>
<li>0.2</li>
</ul>
</div>
    <div id="texto">
   </div>
  
    
 </>   
    
    );
}



export default Corpo;