import React from "react";
import './cabeca.css';
import {Link} from "react-router-dom";

function Cabecalho (){
return(
<div id={'navegacao'}>
    <a id="rr" href="./"  rel="noreferrer">
    <h1 id="logo">Kafocolo</h1>
    </a>

    <div id="area">
            <div id={'menu'}>
                <Link to={'/'}>Home</Link>
                <Link to={'Account'}>Account</Link>
                <Link to={'Dashboard'}>Dashboard</Link>
                <Link to={'Perfil'}>Perfil</Link>
            </div>

    </div>
    
</div>
)
}
export default Cabecalho;