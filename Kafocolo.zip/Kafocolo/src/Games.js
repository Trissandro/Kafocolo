import './corpo.css'

function Games({imagem}){
    return(
<div id="corpo">
<h1 id="DP">ISPTEC DA DEPRESSÃO</h1>
<h4 id="text">Postado em 23 - Novembro - 2022</h4>

<div id="texto">
<div id="imagem2"> 
<img src={imagem} alt="Não pega"></img>
</div>
    <p >O Trissandro decide visitar a avó que vive no Huambo em três dias, para fazer a viagem, ele ligou para a agência de viagens para agendar a sua ida. A agência de viagem pediu os seus dados, e para que ele pudesse pagar por transferência ou cartão multicaixa devido a sua preferência, lhe foi enviado as coordenadas bancárias da agência por meio de uma mensagem de texto, que o Trissandro pagou no mesmo dia e a sua viagem foi confirmada.O Trissandro decide visitar a avó que vive no Huambo em três dias, para fazer a viagem, ele ligou para a agência de viagens para agendar a sua ida. A agência de viagem pediu os seus dados, e para que ele pudesse pagar por transferência ou cartão multicaixa devido a sua preferência, lhe foi enviado as coordenadas bancárias da agência por meio de uma mensagem de texto, que o Trissandro pagou no mesmo dia e a sua viagem foi confirmada.<br></br>3
    O Trissandro decide visitar a avó que vive no Huambo em três dias, para fazer a viagem, ele ligou para a agência de viagens para agendar a sua ida. A agência de viagem pediu os seus dados, e para que ele pudesse pagar por transferência ou cartão multicaixa devido a sua preferência, lhe foi enviado as coordenadas bancárias da agência por meio de uma mensagem de texto, que o Trissandro pagou no mesmo dia e a sua viagem foi confirmada.O Trissandro decide visitar a avó que vive no Huambo em três dias, para fazer a viagem, ele ligou para a agência de viagens para agendar a sua ida.</p></div>
    <p id="post">Postado por Judson Paiva</p>
</div>
    
    
    );
}



export default Games;