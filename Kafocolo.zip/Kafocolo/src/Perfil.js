import React from "react";
import './perfil.css'
import img from './person.png';

function Perfil(){
    return(
        <>
        <div>
            <div id="imagem1"> 
                <img  id="person"src={img} alt="Não pegou"></img>
            </div>
            <p id="bemv">Bem-Vindo, “Usuário”</p>
        </div>
        <div id="infot"> 
		<h2> Informação Pessoal</h2>
		<ul id="cabecaident">
		<li id="pr">Nome</li>
		<li>ID</li>
		<li>Saldo</li>
		</ul>
		<ul id="corpoident">
		<li id="pr">Usuário</li>
		<li>0001</li>
		<li>2.000.000,00 kz</li>
		</ul>
		<a id="Editar1" href="./Entrar"  rel="noreferrer">
			Editar
		</a>
        </div>
        <div id="infoc">
		<h2> Informação de Contacto</h2>
		<ul id="cabecaident">
		<li id="pr">Email</li>
		<li>Número</li>
		<li>Palavra-Passe</li>
		</ul>
		<ul id="corpoident">
		<li id="pr">Usuário@kafocolo.com</li>
		<li>+244 923332244</li>
		<li>********</li>
		</ul>
		<a id="Editar2" href="./Entrar"  rel="noreferrer">
			Editar
		</a>
		</div>
        </>
    );
}

export default Perfil;