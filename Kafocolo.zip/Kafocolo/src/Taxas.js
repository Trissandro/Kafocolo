import React from "react";
import './Taxas.css';

function Taxas(){
    return(
        <>
        <div id="lado">
       <a id="simulacao" href="./Account.js">Simulação</a><br></br>
       <a id="conversao" href="./Conversao">Conversão</a><br></br>
       <a id="transferencia" href="./Transferencia">Transferência</a><br></br>
       <a id="taxas" href="./Taxas">Taxas</a>
    </div>
    <h2 id="saldo8">Saldo</h2>
    <h3 id="saldo9">2.000.000,00 kz</h3>
    <div id="infop8"> 
    <h3 id="sim">Taxas</h3>
    <p id="brev3">Brevemente</p>
	<p id="conv3">A Taxa de conversão varia dependendo do câmbio do dia.</p>
        </div>
        </>
    );
}

export default Taxas;