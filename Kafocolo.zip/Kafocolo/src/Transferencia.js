import React from "react";
import './Transferencia.css';
import { useState } from "react";

function Transferencia(){
    /*const [str, setStr]= useState("Trissandro");
    function escrever(str2){
    var  V=[alteracao];
        setStr(str2+" "+V)
        }
    function alteracao(e){
            console.log(e.target.value)
               <h2>{str}</h2>
        }*/
const [valornome, setName] = useState("");
const [visanome, setVisanome]=useState("");
  const Entradas = (event) => {
    event.preventDefault();
    alert(`Transferência efectuada com sucesso no valor de: ${valornome} para: ${visanome}`);
  }
    return(
        <>
        <div id="lado">
       <a id="simulacao" href="./Account.js">Simulação</a><br></br>
       <a id="conversao" href="./Conversao">Conversão</a><br></br>
       <a id="transferencia" href="./Transferencia">Transferência</a><br></br>
       <a id="taxas" href="./Taxas">Taxas</a>
    </div>
    <h2 id="saldo10">Saldo</h2>
    <h3 id="saldo11">2.000.000,00 kz</h3>
    <div id="infop4"> 
    <h3 id="transfer">Transferência</h3>
    <form onSubmit={Entradas}>
    <label id="moedas">Moeda</label>
    <input id="moedanome" placeholder="Ex.Kwanza Angolano" type="text"/>
    <label id="paras">Para</label>
    <input id="paranome" placeholder="Carteira Digital" type="text"/>
    <label id="valor">Valor</label>
    <input id="valornome" value={valornome} 
     onChange={(e)=>setName(e.target.value)} 
    placeholder="Ex.2.000" type="text"/>
    <label id="visa">Visa</label>
    <input id="visanome" value={visanome} 
     onChange={(e)=>setVisanome(e.target.value)}placeholder="Número do Cartão" type="number"/>
	<p id="conv5">A Transferência está sujeita a uma taxa, ela depende do câmbio do dia.</p>
    <button id="transferir" type="submit">Transferência</button>
    </form>
        </div>
        </>
    );
   
}

export default Transferencia;