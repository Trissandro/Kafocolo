import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Cabecalho from './Cabeca';
import Corpo from './Corpo';
import Perfil from './Perfil';
import Rodape from './Rodape';
import Account from './Account';
import Dashboard from './Dashboard';
import Transferencia from './Transferencia';
import Conversao from './Conversao';
import Taxas from './Taxas'
import Entrar from './Entrar';
import useToken from './useToken';







function App() {
  const { token, setToken } = useToken();


  if(!token) {
    return <Entrar setToken={setToken} />
  }
  return (
    <>
    <div>
      <Router>
      <Cabecalho></Cabecalho>
      <Routes>
        <Route path="/" element={<Corpo/>}/>
        <Route path="Account" element={<Account/>}/>
        <Route path="Dashboard" element={<Dashboard/>}/>
        <Route path="Perfil" element={<Perfil/>}/>
        <Route path="Transferencia" element={<Transferencia/>}/>
        <Route path="Conversao" element={<Conversao/>}/>
        <Route path="Taxas" element={<Taxas/>}/>

      </Routes>
        <Rodape></Rodape> 
      </Router>
     
    </div>
    <div>
    </div>
  {/*<div>
   
      
          <Transferencia></Transferencia>
      <Entrar></Entrar>
      <Corpo
     imagem={img}
      ></Corpo>
      <Games 
      //imagem={img2}
      ></Games>
      <Games
      //imagem={img2}
      ></Games>
    </div>*/}
    </>
    
  );
}

export default App;
