import React, { useState } from 'react';
import PropTypes from 'prop-types';
import './Entrar.css';

async function loginUser(credentials) {
 return fetch('http://localhost:8080/login', {
   method: 'POST',
   headers: {
     'Content-Type': 'application/json'
   },
   body: JSON.stringify(credentials)
 })
   .then(data => data.json())
}
function Entrar({setToken}){
    const [username, setUserName] = useState();
    const [password, setPassword] = useState();
    const handleSubmit = async e => {
        e.preventDefault();
        const token = await loginUser({
          username,
          password
        });
        setToken(token);
      }
    return(
        <>
            <div id="esquerdo">
                <h1 id="logo1">Kafocolo</h1>
                <p id="bem"> Bem-Vindo à Kafocolo</p>
                <p>O melhor amigo do teu dinheiro.</p>
                <p id="p1">Tens em mão um verdadeiro guia para as suas finanças</p>
                <p id="reserved">© all directs reserved to</p> <p id="kaf">KafocoloInc.</p>
             </div>
            <div id="direito">
                <form onSubmit={handleSubmit}><p id="Entrar1">Entrar</p>
                <label id="usu" for="usuario">Usuário</label>
                <input type="text" id="usuario"onChange={e => setUserName(e.target.value)} />
                <label id="sen" for="senha">Senha</label>
                <input type="password" id="senha"onChange={e => setPassword(e.target.value)} />
                <input type="submit" id="login" value="Entrar"/></form>
             </div>
        </>
    );
}
export default Entrar;
Entrar.propTypes = {
    setToken: PropTypes.func.isRequired
}