import React from "react";
import './Rodape.css';

function Rodape(){

    return(

        <>
        <div id="foot">
        <table id="table">
			<thead >
				<tr id="tcabeca">
				<th>Sobre Nós</th>
				<th>Serviços</th>
				<th>Suporte</th>
				</tr>
			</thead>
			<tbody>
				<tr>
				<td>Contactos</td>
				<td>Comprar</td>
				<td>Feed-back</td>
				</tr>
                <tr>
				<td>Carreiras</td>
				<td>Vender</td>
				<td>Solicitação</td>
				</tr>
                <tr>
				<td>Privacidade</td>
				<td>Câmbio</td>
				<td>Denúncia</td>
				</tr>
			</tbody>
		</table>
        </div>
        </>
    );
}


export default Rodape;