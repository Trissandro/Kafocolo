# Streaming (VOD + Live) — Grupo 23 (Sistema de TV Corporativa)

Implementa os 2 modos exigidos pelo enunciado:
- **Streaming Sob Demanda (VOD)** — HTTP Range (reproduz sem baixar tudo).
- **Streaming em Tempo Real (Live)** — câmara do telemóvel -> WebSocket -> viewers.

## Pré-requisito
- No servidor: `npm install ws`
- Ter aplicado a **Solução 2** do download (auth.js aceita `?token=`),
  porque o `<video>` e o live usam token na query.

## Ficheiros a adicionar/substituir

### Servidor
| Ficheiro do ZIP | Caminho no projeto | Ação |
|---|---|---|
| server/src/controllers/streamController.js | server/src/controllers/streamController.js | NOVO |
| server/src/routes/streamRoutes.js | server/src/routes/streamRoutes.js | NOVO |
| server/src/live/liveServer.js | server/src/live/liveServer.js | NOVO |
| server/src/_TRECHO_server.js | server.js / app.js / index.js | INTEGRAR o trecho |

### Cliente
| Ficheiro do ZIP | Caminho no projeto | Ação |
|---|---|---|
| client/src/components/Player.jsx | client/src/components/Player.jsx | SUBSTITUIR |
| client/src/pages/LiveBroadcast.jsx | client/src/pages/LiveBroadcast.jsx | NOVO |
| client/src/pages/LiveWatch.jsx | client/src/pages/LiveWatch.jsx | NOVO |
| client/src/_TRECHO_App_rotas.jsx | client/src/App.jsx | ADICIONAR rotas |

## Endpoints
- VOD:  GET /api/stream/:id        -> streaming progressivo (Range)
- Live: ws://<host>/live           -> WebSocket (broadcaster e viewers)

## Rotas do cliente
- /live/emitir       -> transmitir (abre a câmara)
- /live/sala/:room   -> assistir (ex.: /live/sala/sala1)

## Como demonstrar na defesa
1. **VOD:** abre um vídeo -> Play/Pause/Seek funcionam (Network mostra status 206 Partial Content).
2. **Live:** num telemóvel abre /live/emitir -> "Iniciar"; noutro dispositivo abre /live/sala/sala1.

## Notas importantes
- A **câmara (getUserMedia)** só funciona em **HTTPS** ou em **localhost**.
  Para testar no telemóvel na LAN, serve o cliente por HTTPS (ex.: `vite --https`)
  ou usa um túnel. Em localhost (PC) funciona sem HTTPS.
- O live usa MediaRecorder (VP8/Opus em WebM) — suportado em Chrome/Edge/Firefox.
- Este live é um "relay" simples (1 emissor -> N viewers), ideal para a demo.
  Para muitos utilizadores em produção usar-se-ia RTMP+HLS (Nginx) ou WebRTC SFU.
