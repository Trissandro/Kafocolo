// =========================================================
//  TRECHO a integrar no teu server.js / app.js / index.js
// =========================================================
import http from 'http';
import express from 'express';
import streamRoutes from './routes/streamRoutes.js';
import { initLiveServer } from './live/liveServer.js';

const app = express();
// ... os teus middlewares e rotas existentes ...

// NOVO: rota de streaming VOD
app.use('/api/stream', streamRoutes);

// Em vez de app.listen(...), cria um servidor HTTP partilhado:
const PORT = process.env.PORT || 3000;
const server = http.createServer(app);

// NOVO: arranca o servidor de LIVE (WebSocket) no mesmo HTTP server
initLiveServer(server);

server.listen(PORT, () => console.log(`🚀 Servidor + Live em http://localhost:${PORT}`));
