import { Router } from 'express';
import { authRequired } from '../middleware/auth.js';
import { streamMedia } from '../controllers/streamController.js';

const router = Router();
// VOD: streaming progressivo com suporte a Range (play/pause/seek)
// Aceita token no header OU ?token=... (ver auth.js da Solucao 2),
// para funcionar dentro de <video src=...>
router.get('/:id', authRequired, streamMedia);

export default router;
