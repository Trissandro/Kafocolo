import fs from 'fs';
import path from 'path';
import pool from '../config/db.js';
import { logAction } from '../utils/logger.js';

// STREAMING SOB DEMANDA (VOD) com suporte a HTTP Range.
// O browser/VLC pede pedacos (bytes) e o servidor envia so o troco pedido,
// permitindo play/pause/seek SEM baixar o ficheiro inteiro.
export async function streamMedia(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM media WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Conteúdo não encontrado.' });

    const media = rows[0];
    const filePath = path.resolve('uploads', media.file_path || media.filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Ficheiro inexistente.' });

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    // tipo MIME basico por extensao
    const ext = path.extname(filePath).toLowerCase();
    const mime = { '.mp4':'video/mp4', '.webm':'video/webm', '.ogg':'video/ogg',
                   '.mp3':'audio/mpeg', '.aac':'audio/aac', '.wav':'audio/wav' }[ext] || 'application/octet-stream';

    if (range) {
      // ex.: "bytes=0-" ou "bytes=1000-2000"
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunkSize = (end - start) + 1;

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': mime,
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      // sem range: envia o ficheiro todo em stream (ainda progressivo)
      res.writeHead(200, { 'Content-Length': fileSize, 'Content-Type': mime });
      fs.createReadStream(filePath).pipe(res);
    }

    await logAction(req.user?.id || null, 'STREAM_VOD', media.title, req.ip);
  } catch (e) {
    if (!res.headersSent) res.status(500).json({ error: 'Erro no streaming.' });
  }
}
