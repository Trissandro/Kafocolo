import { WebSocketServer } from 'ws';

// LIVE STREAMING (tempo real) por WebSocket.
// Modelo simples de "relay": 1 broadcaster -> N viewers, por sala (roomId).
// O broadcaster (telemovel) captura a camera com MediaRecorder e envia
// blobs de video; o servidor reencaminha esses blobs para os viewers.
export function initLiveServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/live' });

  // rooms: { roomId: { broadcaster: ws|null, viewers: Set<ws> } }
  const rooms = new Map();
  const getRoom = (id) => {
    if (!rooms.has(id)) rooms.set(id, { broadcaster: null, viewers: new Set() });
    return rooms.get(id);
  };

  wss.on('connection', (ws) => {
    ws.role = null; ws.roomId = null;

    ws.on('message', (data, isBinary) => {
      // Mensagens de controlo chegam como JSON (texto); media chega como binario.
      if (!isBinary) {
        let msg; try { msg = JSON.parse(data.toString()); } catch { return; }

        if (msg.type === 'broadcaster') {
          ws.role = 'broadcaster'; ws.roomId = msg.roomId;
          const room = getRoom(msg.roomId);
          room.broadcaster = ws;
          // avisa viewers que a transmissao comecou
          room.viewers.forEach(v => v.readyState === 1 && v.send(JSON.stringify({ type:'live-started' })));
        }

        if (msg.type === 'viewer') {
          ws.role = 'viewer'; ws.roomId = msg.roomId;
          const room = getRoom(msg.roomId);
          room.viewers.add(ws);
          ws.send(JSON.stringify({ type: room.broadcaster ? 'live-started' : 'live-waiting' }));
        }
        return;
      }

      // Binario = chunk de video do broadcaster -> reenvia a todos os viewers
      if (ws.role === 'broadcaster' && ws.roomId) {
        const room = getRoom(ws.roomId);
        room.viewers.forEach(v => v.readyState === 1 && v.send(data, { binary: true }));
      }
    });

    ws.on('close', () => {
      if (!ws.roomId) return;
      const room = getRoom(ws.roomId);
      if (ws.role === 'broadcaster') {
        room.broadcaster = null;
        room.viewers.forEach(v => v.readyState === 1 && v.send(JSON.stringify({ type:'live-ended' })));
      } else if (ws.role === 'viewer') {
        room.viewers.delete(ws);
      }
    });
  });

  console.log('🔴 Live WebSocket server pronto em  ws://<host>/live');
}
