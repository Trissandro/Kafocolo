# Protocolos usados (para o Relatório Técnico)

| Função | Protocolo | Onde no projeto |
|---|---|---|
| API REST / autenticação | HTTP(S) + JWT | rotas /api/... , auth.js |
| Download de ficheiros | HTTP(S) | /api/media/:id/download |
| Streaming VOD (offline) | HTTP(S) com **Range / 206 Partial Content** | /api/stream/:id |
| Streaming Live (online) | **WebSocket (ws/wss)** sobre TCP | /live |
| Base de dados | TCP (MySQL) | config/db.js |
| (Opcional) Transferência em massa | **FTP** (vsftpd / FileZilla) | servidor de ficheiros |

## Porquê estas escolhas
- **HTTP Range (VOD):** o cliente pede intervalos de bytes; o servidor responde com
  `206 Partial Content`. Permite *play/pause/seek* sem descarregar o ficheiro inteiro
  → cumpre "streaming progressivo".
- **WebSocket (Live):** canal bidirecional e de baixa latência sobre TCP; o emissor
  envia chunks de vídeo (MediaRecorder) e o servidor reencaminha aos viewers em tempo real.
- **JWT sobre HTTPS:** autenticação stateless e segurança básica da comunicação.

## Ambiente de rede (LAN)
- Servidor e clientes na mesma rede, servidor com **IP fixo** (ex.: 192.168.1.10).
- Cliente acede a `http(s)://192.168.1.10:PORT`.
- Para a câmara no telemóvel: usar **HTTPS** (getUserMedia exige contexto seguro).
