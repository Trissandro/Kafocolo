import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';

// LIVE - VIEWER: recebe os chunks via WebSocket e reproduz com MediaSource.
export default function LiveWatch() {
  const { room = 'sala1' } = useParams();
  const videoRef = useRef(null);
  const [status, setStatus] = useState('A ligar...');

  useEffect(() => {
    const mediaSource = new MediaSource();
    videoRef.current.src = URL.createObjectURL(mediaSource);
    let sb; const queue = [];

    const append = () => {
      if (sb && !sb.updating && queue.length) sb.appendBuffer(queue.shift());
    };

    mediaSource.addEventListener('sourceopen', () => {
      sb = mediaSource.addSourceBuffer('video/webm;codecs=vp8,opus');
      sb.addEventListener('updateend', append);
    });

    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/live`);
    ws.binaryType = 'arraybuffer';

    ws.onopen = () => ws.send(JSON.stringify({ type: 'viewer', roomId: room }));
    ws.onmessage = (ev) => {
      if (typeof ev.data === 'string') {
        const m = JSON.parse(ev.data);
        if (m.type === 'live-started') setStatus('🔴 AO VIVO');
        if (m.type === 'live-waiting') setStatus('À espera do emissor...');
        if (m.type === 'live-ended')   setStatus('Transmissão terminada.');
        return;
      }
      queue.push(new Uint8Array(ev.data));
      append();
    };

    return () => ws.close();
  }, [room]);

  return (
    <div className="container">
      <h2>📺 Ao Vivo — sala {room}</h2>
      <div className="info">{status}</div>
      <video ref={videoRef} autoPlay playsInline controls style={{ width:'100%', maxHeight:480, background:'#000' }} />
    </div>
  );
}
