import { useRef, useState } from 'react';

// LIVE - BROADCASTER: captura a camera/microfone do dispositivo (telemovel)
// e envia chunks via WebSocket para o servidor reencaminhar aos viewers.
export default function LiveBroadcast() {
  const videoRef = useRef(null);
  const wsRef = useRef(null);
  const recRef = useRef(null);
  const [on, setOn] = useState(false);
  const [room, setRoom] = useState('sala1');

  async function start() {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    videoRef.current.srcObject = stream;

    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/live`);
    ws.binaryType = 'arraybuffer';
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'broadcaster', roomId: room }));
      // MediaRecorder gera blobs de video em pequenos intervalos
      const rec = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp8,opus' });
      recRef.current = rec;
      rec.ondataavailable = (e) => {
        if (e.data.size > 0 && ws.readyState === 1) e.data.arrayBuffer().then(buf => ws.send(buf));
      };
      rec.start(500); // envia um chunk a cada 500ms
      setOn(true);
    };
  }

  function stop() {
    recRef.current?.stop();
    wsRef.current?.close();
    videoRef.current?.srcObject?.getTracks().forEach(t => t.stop());
    setOn(false);
  }

  return (
    <div className="container">
      <h2>🔴 Transmissão Ao Vivo (Emitir)</h2>
      <input value={room} onChange={e=>setRoom(e.target.value)} placeholder="Sala" disabled={on} />
      <video ref={videoRef} autoPlay muted playsInline style={{ width:'100%', maxHeight:480, background:'#000' }} />
      {!on
        ? <button className="btn" onClick={start}>▶ Iniciar transmissão</button>
        : <button className="btn-del" onClick={stop}>⏹ Parar transmissão</button>}
      <p className="muted">Partilha o link da sala "<b>{room}</b>" para outros assistirem.</p>
    </div>
  );
}
