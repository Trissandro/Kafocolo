// =========================================================
//  Adiciona estas rotas no teu App.jsx (React Router)
// =========================================================
import LiveBroadcast from './pages/LiveBroadcast.jsx';
import LiveWatch from './pages/LiveWatch.jsx';

// dentro de <Routes>:
//   <Route path="/live/emitir"      element={<LiveBroadcast />} />
//   <Route path="/live/sala/:room"  element={<LiveWatch />} />
