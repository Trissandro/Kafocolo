import { useMemo } from 'react';

// Player de VOD: o elemento <video>/<audio> faz pedidos com Range
// automaticamente ao endpoint /api/stream/:id -> streaming sem download total.
export default function Player({ media }) {
  const token = localStorage.getItem('token');
  // token na query para o <video> conseguir autenticar (Solucao 2)
  const src = useMemo(
    () => `/api/stream/${media.id}?token=${token}`,
    [media.id, token]
  );

  const isAudio = (media.type || '').startsWith('audio') ||
                  /\.(mp3|aac|wav|ogg)$/i.test(media.file_path || media.filename || '');

  return isAudio ? (
    <audio src={src} controls style={{ width: '100%' }} />
  ) : (
    <video src={src} controls style={{ width: '100%', maxHeight: 480, background:'#000' }} />
  );
}
