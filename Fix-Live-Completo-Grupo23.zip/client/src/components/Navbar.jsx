import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const out = () => { logout(); nav('/login'); };

  if (!user) return null;
  return (
    <nav className="navbar">
      <div className="brand">📺 TV Corporativa <span>Grupo 23</span></div>
      <div className="links">
        <Link to="/">Início</Link>
        <Link to="/radio">Rádio</Link>
        <Link to="/tv">TV Aberta</Link>

        {/* assistir: vai para a LISTA de salas abertas */}
        <Link to="/live">🔴 Ao Vivo</Link>
        {/* transmitir: so admin */}
        {user.role === 'admin' && <Link to="/live/emitir">📡 Transmitir</Link>}

        {user.role === 'admin' && <Link to="/upload">Upload</Link>}
        {user.role === 'admin' && <Link to="/criar-utilizador">Criar Utilizador</Link>}
        {(user.role === 'admin' || user.role === 'editor') && <Link to="/admin">Painel</Link>}
        <Link to="/perfil">Perfil</Link>
        <span className="user">{user.name} ({user.role})</span>
        <button onClick={out}>Sair</button>
      </div>
    </nav>
  );
}
