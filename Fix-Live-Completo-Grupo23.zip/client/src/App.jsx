import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Navbar from './components/Navbar.jsx';
import Login from './pages/Login.jsx';
import Home from './pages/Home.jsx';
import MediaDetail from './pages/MediaDetail.jsx';
import Upload from './pages/Upload.jsx';
import Admin from './pages/Admin.jsx';
import Profile from './pages/Profile.jsx';
import CreateUser from './pages/CreateUser.jsx';
import Radio from './pages/Radio.jsx';
import TV from './pages/TV.jsx';
import LiveBroadcast from './pages/LiveBroadcast.jsx';
import LiveWatch from './pages/LiveWatch.jsx';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="container">A carregar...</div>;
  return user ? children : <Navigate to="/login" />;
}
function RoleRoute({ role, children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="container">A carregar...</div>;
  if (!user) return <Navigate to="/login" />;
  return user.role === role ? children : <Navigate to="/" />;
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Protected><Home /></Protected>} />
        <Route path="/media/:id" element={<Protected><MediaDetail /></Protected>} />
        <Route path="/radio" element={<Protected><Radio /></Protected>} />
        <Route path="/tv" element={<Protected><TV /></Protected>} />
        <Route path="/perfil" element={<Protected><Profile /></Protected>} />

        {/* LIVE: lista de salas (assistir) e emitir (admin) */}
        <Route path="/live" element={<Protected><LiveWatch /></Protected>} />
        <Route path="/live/emitir" element={<RoleRoute role="admin"><LiveBroadcast /></RoleRoute>} />

        <Route path="/upload" element={<RoleRoute role="admin"><Upload /></RoleRoute>} />
        <Route path="/criar-utilizador" element={<RoleRoute role="admin"><CreateUser /></RoleRoute>} />
        <Route path="/admin" element={<Protected><Admin /></Protected>} />
      </Routes>
    </>
  );
}
