import { useEffect, useRef, useState } from 'react';

// LIVE - VIEWER: 1) lista salas abertas; 2) ao escolher, liga-se e reproduz com MediaSource.
export default function LiveWatch() {
  const videoRef = useRef(null);
  const wsRef = useRef(null);
  const [rooms, setRooms] = useState([]);
  const [room, setRoom] = useState(null);      // sala escolhida
  const [status, setStatus] = useState('');

  // --- LISTA de salas abertas (liga ao /live e pede 'list') ---
  useEffect(() => {
    if (room) return; // se ja estamos a ver uma sala, nao lista
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/live`);
    ws.onopen = () => ws.send(JSON.stringify({ type: 'list' }));
    ws.onmessage = (ev) => {
      try { const m = JSON.parse(ev.data); if (m.type === 'rooms') setRooms(m.rooms); } catch {}
    };
    return () => ws.close();
  }, [room]);

  // --- VER a sala escolhida ---
  useEffect(() => {
    if (!room) return;
    setStatus('A ligar...');
    const mediaSource = new MediaSource();
    videoRef.current.src = URL.createObjectURL(mediaSource);
    let sb; const queue = [];
    const append = () => { if (sb && !sb.updating && queue.length) sb.appendBuffer(queue.shift()); };

    mediaSource.addEventListener('sourceopen', () => {
      sb = mediaSource.addSourceBuffer('video/webm;codecs=vp8,opus');
      sb.addEventListener('updateend', append);
    });

    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${proto}://${location.host}/live`);
    ws.binaryType = 'arraybuffer';
    wsRef.current = ws;

    ws.onopen = () => ws.send(JSON.stringify({ type: 'viewer', roomId: room }));
    ws.onmessage = (ev) => {
      if (typeof ev.data === 'string') {
        const m = JSON.parse(ev.data);
        if (m.type === 'live-started') setStatus('🔴 AO VIVO');
        if (m.type === 'no-room')      { setStatus('Sala indisponível.'); setRoom(null); }
        if (m.type === 'live-ended')   { setStatus('Transmissão terminada.'); }
        return;
      }
      queue.push(new Uint8Array(ev.data));
      append();
    };

    return () => ws.close();
  }, [room]);

  // ECRA 1: escolher sala
  if (!room) {
    return (
      <div className="container">
        <h2>📺 Transmissões Ao Vivo</h2>
        {rooms.length === 0 ? (
          <p className="muted">Não há transmissões ativas de momento.</p>
        ) : (
          <ul style={{ listStyle:'none', padding:0 }}>
            {rooms.map(r => (
              <li key={r.roomId} style={{ display:'flex', justifyContent:'space-between',
                  alignItems:'center', padding:'10px 14px', border:'1px solid #ddd',
                  borderRadius:8, marginBottom:8 }}>
                <span>🔴 <b>{r.title}</b> — {r.viewers} a assistir</span>
                <button className="btn" onClick={() => setRoom(r.roomId)}>Assistir</button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  // ECRA 2: a assistir
  return (
    <div className="container">
      <h2>📺 Ao Vivo — sala {room}</h2>
      <div className="info">{status}</div>
      <video ref={videoRef} autoPlay playsInline controls
             style={{ width:'100%', maxHeight:480, background:'#000', borderRadius:8 }} />
      <div style={{ marginTop:10 }}>
        <button className="btn" onClick={() => { wsRef.current?.close(); setRoom(null); }}>
          ⬅ Voltar às salas
        </button>
      </div>
    </div>
  );
}
