import { WebSocketServer } from 'ws';

// LIVE STREAMING por WebSocket (relay simples: 1 broadcaster -> N viewers por sala).
// Suporta: criar/fechar salas dinamicamente, listar salas abertas e
// guardar o "header" do MediaRecorder para novos viewers entrarem a meio.
export function initLiveServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/live' });

  // rooms: Map<roomId, { broadcaster, viewers:Set, header:Buffer|null, title }>
  const rooms = new Map();
  const getRoom = (id) => rooms.get(id);

  // envia a lista de salas abertas a TODOS os clientes ligados
  function broadcastRoomList() {
    const list = [...rooms.entries()]
      .filter(([, r]) => r.broadcaster)               // so salas com emissor ativo
      .map(([id, r]) => ({ roomId: id, title: r.title, viewers: r.viewers.size }));
    const payload = JSON.stringify({ type: 'rooms', rooms: list });
    wss.clients.forEach(c => c.readyState === 1 && c.send(payload));
  }

  wss.on('connection', (ws) => {
    ws.role = null; ws.roomId = null;

    ws.on('message', (data, isBinary) => {
      if (!isBinary) {
        let msg; try { msg = JSON.parse(data.toString()); } catch { return; }

        // pedir lista de salas abertas
        if (msg.type === 'list') {
          const list = [...rooms.entries()]
            .filter(([, r]) => r.broadcaster)
            .map(([id, r]) => ({ roomId: id, title: r.title, viewers: r.viewers.size }));
          ws.send(JSON.stringify({ type: 'rooms', rooms: list }));
          return;
        }

        // EMISSOR cria/abre a sala
        if (msg.type === 'broadcaster') {
          ws.role = 'broadcaster'; ws.roomId = msg.roomId;
          rooms.set(msg.roomId, {
            broadcaster: ws, viewers: new Set(), header: null,
            title: msg.title || msg.roomId,
          });
          broadcastRoomList();
        }

        // VIEWER entra numa sala existente
        if (msg.type === 'viewer') {
          const room = getRoom(msg.roomId);
          if (!room || !room.broadcaster) {
            ws.send(JSON.stringify({ type: 'no-room' }));
            return;
          }
          ws.role = 'viewer'; ws.roomId = msg.roomId;
          room.viewers.add(ws);
          ws.send(JSON.stringify({ type: 'live-started' }));
          // reenvia o header (primeiro chunk) para o viewer conseguir descodificar
          if (room.header) ws.send(room.header, { binary: true });
          broadcastRoomList();
        }

        // EMISSOR termina explicitamente -> fecha a sala
        if (msg.type === 'stop' && ws.role === 'broadcaster' && ws.roomId) {
          const room = getRoom(ws.roomId);
          if (room) {
            room.viewers.forEach(v => v.readyState === 1 && v.send(JSON.stringify({ type:'live-ended' })));
            rooms.delete(ws.roomId);
            broadcastRoomList();
          }
        }
        return;
      }

      // BINARIO = chunk de video do emissor -> guarda header e reenvia aos viewers
      if (ws.role === 'broadcaster' && ws.roomId) {
        const room = getRoom(ws.roomId);
        if (!room) return;
        if (!room.header) room.header = Buffer.from(data);   // 1o chunk = cabecalho WebM
        room.viewers.forEach(v => v.readyState === 1 && v.send(data, { binary: true }));
      }
    });

    ws.on('close', () => {
      if (!ws.roomId) return;
      const room = getRoom(ws.roomId);
      if (!room) return;
      if (ws.role === 'broadcaster') {
        // emissor caiu -> avisa viewers e FECHA a sala automaticamente
        room.viewers.forEach(v => v.readyState === 1 && v.send(JSON.stringify({ type:'live-ended' })));
        rooms.delete(ws.roomId);
        broadcastRoomList();
      } else if (ws.role === 'viewer') {
        room.viewers.delete(ws);
        broadcastRoomList();
      }
    });
  });

  console.log('🔴 Live WebSocket server pronto em  ws://<host>/live');
}
