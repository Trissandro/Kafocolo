# Live completa (salas + controlos) — Grupo 23

## O que estava errado
- A live NUNCA iniciava porque o Vite NAO encaminhava o WebSocket /live para o backend
  (so tinha proxy para /api). Os pedidos "live" ficavam pendentes (ver imagem: socket a girar).
- Nao havia controlos (som/camara/parar) nem escolha de salas.

## Ficheiros alterados (6)
| # | Ficheiro | O que mudou |
|---|---|---|
| 1 | client/vite.config.js                | + proxy WebSocket: '/live' -> ws://localhost:4000 (ws:true)  **(corrige o "nunca inicia")** |
| 2 | server/src/live/liveServer.js        | salas dinamicas + listar salas + guardar header + FECHO automatico da sala |
| 3 | client/src/pages/LiveBroadcast.jsx   | botoes: 🔊 som on/off, 📷 camara on/off, ⏹ terminar (fecha a sala) |
| 4 | client/src/pages/LiveWatch.jsx       | lista salas abertas -> escolher -> assistir; botao voltar |
| 5 | client/src/components/Navbar.jsx     | "🔴 Ao Vivo" passa a abrir a LISTA de salas (/live) |
| 6 | client/src/App.jsx                   | rota /live = lista de salas |

## IMPORTANTE
Depois de substituir, **reinicia o cliente (Vite)** — o proxy so aplica no arranque:
    cd client
    Ctrl+C  e  npm run dev

## Fluxo
- Admin -> 📡 Transmitir -> escreve nome da sala -> ▶ Iniciar -> aparece a transmissao.
  Botoes: 🔊/🔇 som, 📷/🚫 camara, ⏹ Terminar (fecha a sala).
- Utilizador -> 🔴 Ao Vivo -> ve a LISTA de salas abertas -> "Assistir".
- Ao Terminar (ou se o emissor sair), a sala fecha e desaparece da lista.
