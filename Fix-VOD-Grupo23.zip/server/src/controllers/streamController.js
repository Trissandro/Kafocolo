import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import pool from '../config/db.js';
import { logAction } from '../utils/logger.js';
dotenv.config();

// Mesma pasta usada no upload (mediaController.js): uploads/media
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
const MEDIA_DIR = path.join(UPLOAD_DIR, 'media');

// STREAMING SOB DEMANDA (VOD) com suporte a HTTP Range.
// O browser pede pedacos (bytes) e o servidor envia so o troco pedido,
// permitindo play/pause/seek SEM baixar o ficheiro inteiro.
export async function streamMedia(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM media WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Conteúdo não encontrado.' });

    const media = rows[0];

    // CORRIGIDO: a coluna correta e' stored_name e a pasta e' uploads/media
    const filePath = path.resolve(MEDIA_DIR, media.stored_name);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Ficheiro inexistente no servidor.' });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    // MIME: usa o guardado na BD; se faltar, deduz pela extensao
    const ext = path.extname(filePath).toLowerCase();
    const mimeByExt = { '.mp4':'video/mp4', '.webm':'video/webm', '.ogg':'video/ogg',
      '.mkv':'video/x-matroska', '.mov':'video/quicktime',
      '.mp3':'audio/mpeg', '.aac':'audio/aac', '.wav':'audio/wav' };
    const mime = media.mime_type || mimeByExt[ext] || 'application/octet-stream';

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunkSize = (end - start) + 1;

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': mime,
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': mime,
        'Accept-Ranges': 'bytes',
      });
      fs.createReadStream(filePath).pipe(res);
    }

    try { await logAction(req.user?.id || null, 'STREAM_VOD', media.title, req.ip); } catch {}
  } catch (e) {
    if (!res.headersSent) res.status(500).json({ error: 'Erro no streaming.' });
  }
}
