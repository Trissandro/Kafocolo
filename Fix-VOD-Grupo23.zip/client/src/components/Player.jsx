import { useMemo } from 'react';

// Player de VOD: o <video>/<audio> faz pedidos com Range automaticamente
// ao endpoint /api/stream/:id -> streaming sem download total.
export default function Player({ media }) {
  const token = localStorage.getItem('token');
  // token na query para o <video> conseguir autenticar (Solucao 2)
  const src = useMemo(
    () => `/api/stream/${media.id}?token=${token}`,
    [media.id, token]
  );

  // a BD tem o campo 'type' = 'video' | 'audio' | 'image'
  const t = (media.type || '').toLowerCase();

  if (t === 'audio') return <audio src={src} controls style={{ width: '100%' }} />;
  if (t === 'image') return <img src={src} alt={media.title} style={{ maxWidth: '100%' }} />;
  return <video src={src} controls style={{ width: '100%', maxHeight: 480, background:'#000' }} />;
}
