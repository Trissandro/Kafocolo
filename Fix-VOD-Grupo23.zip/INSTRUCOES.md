# Correção do VOD (streaming não reproduzia) — Grupo 23

## Causa
O streamController procurava colunas inexistentes (`file_path`/`filename`) e na pasta
errada (`uploads/`). A BD usa a coluna **stored_name** e a pasta **uploads/media**.

## Ficheiros alterados
1. server/src/controllers/streamController.js  -> usa stored_name + uploads/media (+ MIME da BD)
2. client/src/components/Player.jsx            -> usa o campo `type` real (video/audio/image)

Substituir ambos pelos do ZIP. Reiniciar servidor e cliente.
