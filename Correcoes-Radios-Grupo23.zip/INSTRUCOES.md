# Correcoes - Grupo 23

## PARTE 1 - Corrigir canais duplicados (Comunicados/Eventos/Formacao/Geral 3x)
A causa: o schema.sql faz INSERT dos canais sem verificacao; cada `npm run migrate` reinseriu-os.

### Passo A (limpar o que ja esta duplicado) - executar UMA vez no MySQL:
- `01_FIX_DUPLICADOS/fix_canais_duplicados.sql`
  (reaponta os media para o canal original, apaga duplicados e adiciona UNIQUE no nome)

### Passo B (evitar duplicar no futuro):
- Substitui o bloco de INSERT de canais no teu `server/database/schema.sql`
  pelo de `01_FIX_DUPLICADOS/schema_seeds_CORRIGIDO.sql` (usa ON DUPLICATE KEY UPDATE).

---

## PARTE 2 - API com os links das radios

### Ficheiros do servidor:
| Ficheiro | Caminho no projeto | Acao |
|---|---|---|
| 02_API_RADIOS/server/src/data/radios.js | server/src/data/radios.js | NOVO |
| 02_API_RADIOS/server/src/controllers/stationsController.js | server/src/controllers/stationsController.js | SUBSTITUIR |
| 02_API_RADIOS/server/src/routes/stationsRoutes.js | server/src/routes/stationsRoutes.js | SUBSTITUIR |

### Cliente:
| Ficheiro | Caminho no projeto | Acao |
|---|---|---|
| 02_API_RADIOS/client/src/pages/Radio.jsx | client/src/pages/Radio.jsx | SUBSTITUIR |

### Endpoints da API de radios:
- GET  /api/stations/radio/catalogo  -> lista base (estatica, sem login)  -> os 5 links
- POST /api/stations/radio/seed      -> (admin) insere a lista base na BD (nao duplica)
- GET  /api/stations/radio           -> radios guardadas na BD
- POST /api/stations/radio           -> (admin) adicionar (rejeita URL repetido)
- DELETE /api/stations/radio/:id     -> (admin) remover

### Como usar no cliente:
Entra em "Radio" como admin e clica em "Carregar radios base" -> popula as 5 radios.

> Nota: alguns URLs (ex.: Power FM com 0r0r0r0r0r0r0) sao exemplos; substitui pelo link real do stream.
