// Lista base de estacoes de radio (links) - Grupo 23
export const RADIOS = [
  { name: 'Radio Nacional de Angola', stream_url: 'https://radiosonline.cloud/rna.ogg', genre: 'Angola' },
  { name: 'RFI Afrique',              stream_url: 'https://rfiafrique64k.ice.infomaniak.ch/rfiafrique-64.mp3', genre: 'Franca / Africa' },
  { name: 'BBC World Service',        stream_url: 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service', genre: 'UK' },
  { name: 'CNN Radio',                stream_url: 'https://tunein.cdnstream1.com/4417_128.mp3', genre: 'USA' },
  { name: 'Power FM Angola',          stream_url: 'https://stream.zeno.fm/0r0r0r0r0r0r0', genre: 'Angola' }
];
