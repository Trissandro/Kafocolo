import { Router } from 'express';
import { authRequired, requireRole } from '../middleware/auth.js';
import {
  listRadios, listRadiosStatic, createRadio, deleteRadio, seedRadios,
  listTv, createTv, deleteTv
} from '../controllers/stationsController.js';

const router = Router();
// Radio
router.get('/radio', authRequired, listRadios);            // radios da BD
router.get('/radio/catalogo', listRadiosStatic);           // API publica com a lista base (links)
router.post('/radio', authRequired, requireRole('admin'), createRadio);
router.post('/radio/seed', authRequired, requireRole('admin'), seedRadios); // popular BD
router.delete('/radio/:id', authRequired, requireRole('admin'), deleteRadio);
// TV
router.get('/tv', authRequired, listTv);
router.post('/tv', authRequired, requireRole('admin'), createTv);
router.delete('/tv/:id', authRequired, requireRole('admin'), deleteTv);
export default router;
