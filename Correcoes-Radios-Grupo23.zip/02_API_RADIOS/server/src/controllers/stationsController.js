import pool from '../config/db.js';
import { logAction } from '../utils/logger.js';
import { RADIOS } from '../data/radios.js';

// ---------- RADIO ----------
export async function listRadios(req, res) {
  const [rows] = await pool.query('SELECT * FROM radio_stations ORDER BY name');
  res.json(rows);
}

// API estatica (sem BD) - devolve sempre a lista base de radios
export function listRadiosStatic(req, res) {
  res.json(RADIOS.map((r, i) => ({ id: i + 1, ...r })));
}

export async function createRadio(req, res) {
  const { name, stream_url, genre, logo_url } = req.body;
  if (!name || !stream_url) return res.status(400).json({ error: 'Nome e URL obrigatorios.' });
  // evita duplicar pelo URL
  const [exists] = await pool.query('SELECT id FROM radio_stations WHERE stream_url = ?', [stream_url]);
  if (exists.length) return res.status(409).json({ error: 'Esta radio (URL) ja existe.' });
  const [r] = await pool.query(
    'INSERT INTO radio_stations (name, stream_url, genre, logo_url, created_by) VALUES (?,?,?,?,?)',
    [name, stream_url, genre || '', logo_url || '', req.user.id]
  );
  await logAction(req.user.id, 'CREATE_RADIO', name, req.ip);
  res.status(201).json({ id: r.insertId, name, stream_url, genre, logo_url });
}

export async function deleteRadio(req, res) {
  await pool.query('DELETE FROM radio_stations WHERE id = ?', [req.params.id]);
  await logAction(req.user.id, 'DELETE_RADIO', `#${req.params.id}`, req.ip);
  res.json({ ok: true });
}

// Popular a BD com a lista base (idempotente) - so admin
export async function seedRadios(req, res) {
  let inseridas = 0;
  for (const r of RADIOS) {
    const [ex] = await pool.query('SELECT id FROM radio_stations WHERE stream_url = ?', [r.stream_url]);
    if (!ex.length) {
      await pool.query(
        'INSERT INTO radio_stations (name, stream_url, genre, created_by) VALUES (?,?,?,?)',
        [r.name, r.stream_url, r.genre, req.user.id]
      );
      inseridas++;
    }
  }
  await logAction(req.user.id, 'SEED_RADIOS', `${inseridas} inseridas`, req.ip);
  res.json({ ok: true, inseridas, total: RADIOS.length });
}

// ---------- TV (inalterado) ----------
export async function listTv(req, res) {
  const [rows] = await pool.query('SELECT * FROM tv_channels ORDER BY name');
  res.json(rows);
}
export async function createTv(req, res) {
  const { name, stream_url, category, logo_url } = req.body;
  if (!name || !stream_url) return res.status(400).json({ error: 'Nome e URL obrigatorios.' });
  const [exists] = await pool.query('SELECT id FROM tv_channels WHERE stream_url = ?', [stream_url]);
  if (exists.length) return res.status(409).json({ error: 'Este canal (URL) ja existe.' });
  const [r] = await pool.query(
    'INSERT INTO tv_channels (name, stream_url, category, logo_url, created_by) VALUES (?,?,?,?,?)',
    [name, stream_url, category || '', logo_url || '', req.user.id]
  );
  await logAction(req.user.id, 'CREATE_TV', name, req.ip);
  res.status(201).json({ id: r.insertId, name, stream_url, category, logo_url });
}
export async function deleteTv(req, res) {
  await pool.query('DELETE FROM tv_channels WHERE id = ?', [req.params.id]);
  await logAction(req.user.id, 'DELETE_TV', `#${req.params.id}`, req.ip);
  res.json({ ok: true });
}
