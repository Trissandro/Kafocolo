import { useEffect, useState } from 'react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Radio() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [playing, setPlaying] = useState(null);
  const [msg, setMsg] = useState('');
  const [form, setForm] = useState({ name:'', stream_url:'', genre:'', logo_url:'' });

  const load = () => api.get('/stations/radio').then(r=>setList(r.data));
  useEffect(() => { load(); }, []);

  const add = async (e) => {
    e.preventDefault(); setMsg('');
    try {
      await api.post('/stations/radio', form);
      setForm({ name:'', stream_url:'', genre:'', logo_url:'' });
      load();
    } catch (e) { setMsg(e.response?.data?.error || 'Erro ao adicionar.'); }
  };
  const remove = async (id) => { await api.delete(`/stations/radio/${id}`); load(); };

  // NOVO: carregar a lista base de radios para a BD
  const seed = async () => {
    setMsg('A carregar radios base...');
    const r = await api.post('/stations/radio/seed');
    setMsg(`${r.data.inseridas} radio(s) adicionada(s) de ${r.data.total}.`);
    load();
  };

  return (
    <div className="container">
      <h2>📻 Sintonias de Rádio</h2>
      {msg && <div className="info">{msg}</div>}

      {user.role === 'admin' && (
        <button className="btn-small" onClick={seed}>⬇ Carregar rádios base</button>
      )}

      {playing && (
        <div className="player-bar">
          <span>🔊 A ouvir: <b>{playing.name}</b></span>
          <audio src={playing.stream_url} controls autoPlay style={{ flex:1 }} />
          <button onClick={()=>setPlaying(null)}>✖ Parar</button>
        </div>
      )}

      <div className="grid">
        {list.map(r => (
          <div className="card" key={r.id}>
            <div className="card-icon">📻</div>
            <div className="card-body">
              <h3>{r.name}</h3>
              <p className="muted">{r.genre}</p>
              <button className="btn-small" onClick={()=>setPlaying(r)}>▶ Ouvir</button>
              <a className="btn-small" href={r.stream_url} target="_blank" rel="noreferrer">↗ Abrir link</a>
              {user.role==='admin' && <button className="btn-del" onClick={()=>remove(r.id)}>🗑</button>}
            </div>
          </div>
        ))}
      </div>

      {user.role === 'admin' && (
        <>
          <h3>Adicionar estação de rádio</h3>
          <form onSubmit={add} className="inline-form">
            <input placeholder="Nome" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required />
            <input placeholder="URL do stream (mp3/aac/ogg)" value={form.stream_url} onChange={e=>setForm({...form,stream_url:e.target.value})} required />
            <input placeholder="Género/País" value={form.genre} onChange={e=>setForm({...form,genre:e.target.value})} />
            <button type="submit">Adicionar</button>
          </form>
        </>
      )}
    </div>
  );
}
