-- =========================================================
--  CORRECAO: remover canais duplicados (Comunicados/Eventos/etc 3x)
--  Executar no MySQL UMA vez.
-- =========================================================
USE tv_corporativa;

-- 1) Reaponta os media que usam canais duplicados para o canal de menor id (o "original")
UPDATE media m
JOIN channels c ON m.channel_id = c.id
JOIN (
  SELECT name, MIN(id) AS keep_id
  FROM channels
  GROUP BY name
) k ON c.name = k.name
SET m.channel_id = k.keep_id
WHERE m.channel_id <> k.keep_id;

-- 2) Apaga os canais duplicados, mantendo apenas o de menor id por nome
DELETE c FROM channels c
JOIN (
  SELECT name, MIN(id) AS keep_id
  FROM channels
  GROUP BY name
) k ON c.name = k.name
WHERE c.id <> k.keep_id;

-- 3) Impede futuros duplicados: nome unico
ALTER TABLE channels ADD UNIQUE KEY uq_channel_name (name);

SELECT * FROM channels;  -- deve mostrar apenas 4 canais
