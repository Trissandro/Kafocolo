import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import basicSsl from '@vitejs/plugin-basic-ssl';

// Configuracao para DESENVOLVIMENTO EM REDE (LAN) com HTTPS.
// - host: true       -> o Vite fica acessivel por outros PCs (0.0.0.0)
// - basicSsl()       -> ativa HTTPS (necessario para a camara/getUserMedia fora de localhost)
// - proxy /api e /live -> tudo passa pela MESMA origem segura (https://IP:5173),
//   por isso NAO ha problemas de "mixed content" e o backend pode continuar em HTTP.
export default defineConfig({
  plugins: [react(), basicSsl()],
  server: {
    host: true,            // expoe na rede local
    port: 5173,
    proxy: {
      // REST/HTTP -> backend
      '/api': { target: 'http://localhost:4000', changeOrigin: true },
      // WebSocket (Live) -> backend
      '/live': { target: 'ws://localhost:4000', ws: true, changeOrigin: true },
    },
  },
});
