import { useMemo } from 'react';

// Player VOD: usa caminho RELATIVO /api/stream/:id (passa pelo proxy do Vite),
// por isso funciona em localhost e noutro PC da rede sem IP fixo.
export default function Player({ media }) {
  const token = localStorage.getItem('token');
  const src = useMemo(
    () => `/api/stream/${media.id}?token=${token}`,
    [media.id, token]
  );

  const t = (media.type || '').toLowerCase();
  if (t === 'audio') return <audio src={src} controls style={{ width: '100%' }} />;
  if (t === 'image') return <img src={src} alt={media.title} style={{ maxWidth: '100%' }} />;
  return <video src={src} controls style={{ width: '100%', maxHeight: 480, background:'#000' }} />;
}
