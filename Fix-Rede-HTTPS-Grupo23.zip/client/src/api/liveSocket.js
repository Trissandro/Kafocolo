// URL do WebSocket de live.
// Usa a MESMA origem do site (host:porta atual). Em DEV, o Vite faz proxy
// de /live -> ws://localhost:4000. Em HTTPS usa wss automaticamente.
// Assim funciona em localhost E noutro PC da rede, sem mixed content.
export function liveWsUrl() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  return `${proto}://${location.host}/live`;   // ex.: wss://192.168.1.10:5173/live
}
