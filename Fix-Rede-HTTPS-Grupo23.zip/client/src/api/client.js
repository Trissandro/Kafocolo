import axios from 'axios';

// baseURL RELATIVO: '/api' passa pelo proxy do Vite -> backend :4000.
// Funciona em localhost e noutro PC da rede sem alterar nada.
const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
