# Aceder ao site noutro PC da MESMA REDE (DESENVOLVIMENTO) — Grupo 23

## Erros que isto resolve
1. "Cannot GET /live"
   -> Estavas a aceder pela porta errada / o WS ligava direto a :4000.
   Agora /live passa pelo PROXY do Vite (mesma origem) e a rota SPA funciona ao atualizar.
2. "Cannot read properties of undefined (reading 'getUserMedia')"
   -> A camara (getUserMedia) so funciona em localhost OU HTTPS. Por IP em HTTP fica undefined.
   Agora o Vite serve em HTTPS (@vitejs/plugin-basic-ssl) -> a camara funciona noutro PC.

## Ficheiros (substituir)
| # | Ficheiro | O que mudou |
|---|---|---|
| 1 | client/vite.config.js          | HTTPS + host:true + proxy /api e /live |
| 2 | client/src/api/liveSocket.js   | WS pela MESMA origem (wss em HTTPS) — sem :4000 fixo |
| 3 | client/src/api/client.js       | baseURL '/api' relativo (passa pelo proxy) |
| 4 | client/src/components/Player.jsx| src relativo /api/stream (VOD em rede) |
| 5 | client/package.json            | + dependencia @vitejs/plugin-basic-ssl |

## PASSOS (fazer por ordem)
1) Instalar o plugin de HTTPS:
       cd client
       npm install -D @vitejs/plugin-basic-ssl

2) Substituir os 5 ficheiros acima.

3) Descobrir o IP do PC-SERVIDOR:
       macOS:   ipconfig getifaddr en0
       Linux:   hostname -I
       Windows: ipconfig   (ver "Endereco IPv4")     ex.: 192.168.1.10

4) Arrancar o BACKEND (continua em HTTP, nao mexes):
       cd server && npm run dev      -> http://localhost:4000

5) Arrancar o CLIENTE:
       cd client && npm run dev
   O Vite mostra um endereco "Network: https://192.168.1.10:5173/"

6) NO OUTRO PC, abrir no browser:
       https://192.168.1.10:5173
   (aceitar o aviso de certificado: Avancado -> Continuar)

## Confirmar
- Network -> "live" -> Status 101 Switching Protocols (WebSocket ligado)
- A camara/microfone agora funciona (estas em HTTPS)

## Firewall (se nao ligar)
Abrir a porta 5173 no PC-SERVIDOR:
   Windows: permitir Node.js / porta 5173 na Firewall
   Linux:   sudo ufw allow 5173
   macOS:   permitir ligacoes de entrada para o Node

NOTA: ja NAO precisas de abrir a 4000 no outro PC, porque tudo passa pelo Vite (5173).
