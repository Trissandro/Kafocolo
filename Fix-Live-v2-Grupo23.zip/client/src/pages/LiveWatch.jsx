import { useEffect, useRef, useState } from 'react';
import { liveWsUrl } from '../api/liveSocket.js';

// LIVE - VIEWER: 1) lista salas; 2) escolher -> assistir (MediaSource).
export default function LiveWatch() {
  const videoRef = useRef(null);
  const wsRef = useRef(null);
  const [rooms, setRooms] = useState([]);
  const [room, setRoom] = useState(null);
  const [status, setStatus] = useState('');

  // LISTA de salas (refaz a cada 3s enquanto estamos no ecra da lista)
  useEffect(() => {
    if (room) return;
    let ws;
    const connect = () => {
      ws = new WebSocket(liveWsUrl());
      ws.onopen = () => ws.send(JSON.stringify({ type: 'list' }));
      ws.onmessage = (ev) => {
        try { const m = JSON.parse(ev.data); if (m.type === 'rooms') setRooms(m.rooms); } catch {}
      };
    };
    connect();
    const t = setInterval(() => { if (ws?.readyState === 1) ws.send(JSON.stringify({ type:'list' })); }, 3000);
    return () => { clearInterval(t); ws?.close(); };
  }, [room]);

  // VER sala escolhida
  useEffect(() => {
    if (!room) return;
    setStatus('A ligar...');

    const ms = new MediaSource();
    videoRef.current.src = URL.createObjectURL(ms);
    let sb = null;
    const queue = [];

    const flush = () => {
      if (!sb || sb.updating || queue.length === 0) return;
      try { sb.appendBuffer(queue.shift()); } catch (e) { /* ignora chunk inicial incompleto */ }
    };

    ms.addEventListener('sourceopen', () => {
      try {
        sb = ms.addSourceBuffer('video/webm;codecs=vp8,opus');
        sb.mode = 'sequence';
        sb.addEventListener('updateend', flush);
      } catch (e) { setStatus('Formato não suportado neste browser.'); }
    });

    const ws = new WebSocket(liveWsUrl());
    ws.binaryType = 'arraybuffer';
    wsRef.current = ws;

    ws.onopen = () => ws.send(JSON.stringify({ type: 'viewer', roomId: room }));
    ws.onmessage = (ev) => {
      if (typeof ev.data === 'string') {
        const m = JSON.parse(ev.data);
        if (m.type === 'live-started') setStatus('🔴 AO VIVO');
        if (m.type === 'no-room')      { setStatus('Sala indisponível.'); setTimeout(()=>setRoom(null), 1200); }
        if (m.type === 'live-ended')   setStatus('Transmissão terminada.');
        return;
      }
      queue.push(new Uint8Array(ev.data));
      flush();
      // tenta dar play (alguns browsers bloqueiam autoplay)
      videoRef.current?.play?.().catch(()=>{});
    };
    ws.onerror = () => setStatus('Erro de ligação.');

    return () => { ws.close(); };
  }, [room]);

  // ECRA 1: lista de salas
  if (!room) {
    return (
      <div className="container">
        <h2>📺 Transmissões Ao Vivo</h2>
        {rooms.length === 0 ? (
          <p className="muted">Não há transmissões ativas de momento.</p>
        ) : (
          <ul style={{ listStyle:'none', padding:0 }}>
            {rooms.map(r => (
              <li key={r.roomId} style={{ display:'flex', justifyContent:'space-between',
                  alignItems:'center', padding:'10px 14px', border:'1px solid #ddd',
                  borderRadius:8, marginBottom:8 }}>
                <span>🔴 <b>{r.title}</b> — {r.viewers} a assistir</span>
                <button className="btn" onClick={() => setRoom(r.roomId)}>Assistir</button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  // ECRA 2: a assistir
  return (
    <div className="container">
      <h2>📺 Ao Vivo — sala {room}</h2>
      <div className="info">{status}</div>
      <video ref={videoRef} autoPlay playsInline controls muted
             style={{ width:'100%', maxHeight:480, background:'#000', borderRadius:8 }} />
      <div style={{ marginTop:10 }}>
        <button className="btn" onClick={() => { wsRef.current?.close(); setRoom(null); }}>
          ⬅ Voltar às salas
        </button>
      </div>
    </div>
  );
}
