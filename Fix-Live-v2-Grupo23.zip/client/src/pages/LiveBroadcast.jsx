import { useRef, useState } from 'react';
import { liveWsUrl } from '../api/liveSocket.js';

// LIVE - EMISSOR: cria sala, captura camera/microfone e envia chunks por WebSocket.
export default function LiveBroadcast() {
  const videoRef = useRef(null);
  const wsRef = useRef(null);
  const recRef = useRef(null);
  const streamRef = useRef(null);

  const [on, setOn] = useState(false);
  const [room, setRoom] = useState('sala1');
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);

  async function start() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      videoRef.current.srcObject = stream;

      const ws = new WebSocket(liveWsUrl());      // liga DIRETO ao backend :4000
      ws.binaryType = 'arraybuffer';
      wsRef.current = ws;

      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'broadcaster', roomId: room, title: room }));
        const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
          ? 'video/webm;codecs=vp8,opus' : 'video/webm';
        const rec = new MediaRecorder(stream, { mimeType: mime });
        recRef.current = rec;
        rec.ondataavailable = (e) => {
          if (e.data.size > 0 && ws.readyState === 1) e.data.arrayBuffer().then(buf => ws.send(buf));
        };
        rec.start(500);
        setOn(true);
      };
      ws.onerror = () => alert('Erro de ligação ao servidor de live (ws://...:4000/live).');
      ws.onclose = () => { if (on) setOn(false); };
    } catch (e) {
      alert('Não foi possível aceder à câmara/microfone: ' + e.message);
    }
  }

  function stop() {
    if (wsRef.current?.readyState === 1) wsRef.current.send(JSON.stringify({ type: 'stop' }));
    try { recRef.current?.stop(); } catch {}
    wsRef.current?.close();
    streamRef.current?.getTracks().forEach(t => t.stop());
    if (videoRef.current) videoRef.current.srcObject = null;
    setOn(false); setMicOn(true); setCamOn(true);
  }

  function toggleMic() {
    const tk = streamRef.current?.getAudioTracks?.()[0];
    if (tk) { tk.enabled = !tk.enabled; setMicOn(tk.enabled); }
  }
  function toggleCam() {
    const tk = streamRef.current?.getVideoTracks?.()[0];
    if (tk) { tk.enabled = !tk.enabled; setCamOn(tk.enabled); }
  }

  return (
    <div className="container">
      <h2>🔴 Transmissão Ao Vivo (Emitir)</h2>

      <label style={{ display:'block', marginBottom:8 }}>
        Nome da sala:&nbsp;
        <input value={room} onChange={e=>setRoom(e.target.value)} disabled={on} placeholder="ex.: sala1" />
      </label>

      <video ref={videoRef} autoPlay muted playsInline
             style={{ width:'100%', maxHeight:480, background:'#000', borderRadius:8 }} />

      {/* BOTOES DE CONTROLO */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginTop:12 }}>
        {!on ? (
          <button className="btn" onClick={start}>▶ Iniciar transmissão</button>
        ) : (
          <>
            <button className="btn-del" onClick={stop}>⏹ Terminar live</button>
            <button className="btn" onClick={toggleMic}>{micOn ? '🔊 Som ligado' : '🔇 Som desligado'}</button>
            <button className="btn" onClick={toggleCam}>{camOn ? '📷 Câmara ligada' : '🚫 Câmara desligada'}</button>
          </>
        )}
      </div>

      {on && <p className="muted" style={{ marginTop:10 }}>
        🔴 Em direto na sala "<b>{room}</b>". Vê em <b>Ao Vivo</b>.
      </p>}
    </div>
  );
}
