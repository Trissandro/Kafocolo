// Constroi o URL do WebSocket de live.
// Liga-se DIRETAMENTE ao backend (porta 4000), em vez de depender do
// proxy do Vite (que costuma falhar com WebSocket). Funciona em LAN tambem.
export function liveWsUrl() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const host = location.hostname;          // ex.: localhost ou 192.168.x.x
  const PORT = 4000;                        // porta do backend
  return `${proto}://${host}:${PORT}/live`;
}
