# Correcao DEFINITIVA da Live — Grupo 23

## Erros encontrados nas imagens
1. CONSOLA: "WebSocket connection to 'ws://localhost:5173/live' failed:
   WebSocket is closed before the connection is established."
   -> O WebSocket ligava-se a 5173 (Vite) e o proxy WS do Vite falhava.
2. BOTOES nao apareciam -> estava a versao ANTIGA do LiveBroadcast.jsx (sem botoes).

## SOLUCAO (a prova de falhas)
O cliente passa a ligar-se DIRETAMENTE ao backend (porta 4000), sem depender
do proxy do Vite. Ver client/src/api/liveSocket.js -> ws://<host>:4000/live

## Ficheiros (substituir TODOS)
| # | Ficheiro | Estado |
|---|---|---|
| 1 | client/src/api/liveSocket.js          | NOVO  (URL do WebSocket -> :4000) |
| 2 | client/src/pages/LiveBroadcast.jsx    | SUBSTITUIR (botoes som/camara/parar + :4000) |
| 3 | client/src/pages/LiveWatch.jsx        | SUBSTITUIR (lista salas + MediaSource robusto + :4000) |
| 4 | client/src/components/Navbar.jsx      | SUBSTITUIR |
| 5 | client/src/App.jsx                    | SUBSTITUIR |
| 6 | server/src/live/liveServer.js         | SUBSTITUIR (salas + header WebM + fecho auto) |
| 7 | server/src/index.js                   | SUBSTITUIR (cors mantido) |

## DEPOIS (importante)
- Reinicia o SERVIDOR (Ctrl+C, npm run dev) -> ve "🔴 Live WebSocket server pronto"
- Reinicia o CLIENTE e faz Ctrl+Shift+R
- Ja NAO precisas de proxy WS no Vite (liga direto a 4000), mas se o tiveres nao faz mal.

## Como confirmar que ligou
F12 -> Network -> clica em "live" -> Status deve ser **101 Switching Protocols**.
Se for 101, esta ligado. Os botoes aparecem assim que clicas em "Iniciar".

## Nota
Emissor e viewer no MESMO browser/PC funciona em localhost.
Para telemovel via LAN: usar HTTPS (getUserMedia exige contexto seguro) e
o backend acessivel em http://<IP>:4000.
