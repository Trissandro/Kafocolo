import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import http from 'http';
import authRoutes from './routes/authRoutes.js';
import mediaRoutes from './routes/mediaRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import stationsRoutes from './routes/stationsRoutes.js';
import streamRoutes from './routes/streamRoutes.js';
import { initLiveServer } from './live/liveServer.js';

dotenv.config();
const app = express();

app.use(cors());                 // permite pedidos do cliente (5173) e WebSocket
app.use(express.json());
app.use(morgan('dev'));

app.use('/api/auth', authRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/stations', stationsRoutes);
app.use('/api/stream', streamRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'TV Corporativa - Grupo 23' }));

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(400).json({ error: err.message });
});

const PORT = process.env.PORT || 4000;
const server = http.createServer(app);

// Servidor de LIVE (WebSocket) no MESMO servidor HTTP, em /live
initLiveServer(server);

server.listen(PORT, () =>
  console.log(`Servidor TV Corporativa a correr em http://localhost:${PORT}`)
);
