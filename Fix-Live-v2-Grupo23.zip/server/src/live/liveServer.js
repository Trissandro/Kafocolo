import { WebSocketServer } from 'ws';

// LIVE por WebSocket (relay: 1 emissor -> N viewers por sala).
// Salas dinamicas, lista de salas, guarda os primeiros chunks (header WebM)
// para novos viewers conseguirem descodificar, e fecho automatico da sala.
export function initLiveServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/live' });

  // rooms: Map<roomId, { broadcaster, viewers:Set, initChunks:Buffer[], title }>
  const rooms = new Map();

  function roomList() {
    return [...rooms.entries()]
      .filter(([, r]) => r.broadcaster)
      .map(([id, r]) => ({ roomId: id, title: r.title, viewers: r.viewers.size }));
  }
  function broadcastRoomList() {
    const payload = JSON.stringify({ type: 'rooms', rooms: roomList() });
    wss.clients.forEach(c => c.readyState === 1 && c.send(payload));
  }
  function closeRoom(id) {
    const room = rooms.get(id);
    if (!room) return;
    room.viewers.forEach(v => v.readyState === 1 && v.send(JSON.stringify({ type:'live-ended' })));
    rooms.delete(id);
    broadcastRoomList();
  }

  wss.on('connection', (ws) => {
    ws.role = null; ws.roomId = null;

    ws.on('message', (data, isBinary) => {
      if (!isBinary) {
        let msg; try { msg = JSON.parse(data.toString()); } catch { return; }

        if (msg.type === 'list') {
          ws.send(JSON.stringify({ type: 'rooms', rooms: roomList() }));
          return;
        }

        if (msg.type === 'broadcaster') {
          ws.role = 'broadcaster'; ws.roomId = msg.roomId;
          rooms.set(msg.roomId, {
            broadcaster: ws, viewers: new Set(), initChunks: [],
            title: msg.title || msg.roomId,
          });
          broadcastRoomList();
          console.log('🔴 Sala aberta:', msg.roomId);
        }

        if (msg.type === 'viewer') {
          const room = rooms.get(msg.roomId);
          if (!room || !room.broadcaster) { ws.send(JSON.stringify({ type:'no-room' })); return; }
          ws.role = 'viewer'; ws.roomId = msg.roomId;
          room.viewers.add(ws);
          ws.send(JSON.stringify({ type:'live-started' }));
          // reenvia os primeiros chunks (cabecalho) para o viewer descodificar
          room.initChunks.forEach(c => ws.readyState === 1 && ws.send(c, { binary: true }));
          broadcastRoomList();
        }

        if (msg.type === 'stop' && ws.role === 'broadcaster' && ws.roomId) {
          closeRoom(ws.roomId);
        }
        return;
      }

      // binario = chunk do emissor
      if (ws.role === 'broadcaster' && ws.roomId) {
        const room = rooms.get(ws.roomId);
        if (!room) return;
        const buf = Buffer.from(data);
        // guarda os primeiros ~3 chunks (contem o cabecalho WebM)
        if (room.initChunks.length < 3) room.initChunks.push(buf);
        room.viewers.forEach(v => v.readyState === 1 && v.send(buf, { binary: true }));
      }
    });

    ws.on('close', () => {
      if (!ws.roomId) return;
      if (ws.role === 'broadcaster') closeRoom(ws.roomId);
      else if (ws.role === 'viewer') {
        const room = rooms.get(ws.roomId);
        if (room) { room.viewers.delete(ws); broadcastRoomList(); }
      }
    });
  });

  console.log('🔴 Live WebSocket server pronto em  ws://<host>:PORT/live');
}
