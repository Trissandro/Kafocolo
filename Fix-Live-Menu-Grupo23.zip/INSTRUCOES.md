# Adicionar Live ao menu — Grupo 23

## O que faltava
O Navbar nao tinha links para a live e o App.jsx nao tinha as rotas /live/...
Por isso nao havia forma de iniciar nem assistir transmissoes.

## Ficheiros alterados (2)
1. client/src/App.jsx                  -> adicionadas rotas /live/emitir e /live/sala/:room
2. client/src/components/Navbar.jsx    -> adicionados links "📡 Transmitir" (admin) e "🔴 Ao Vivo"

## Permissoes
- 📡 Transmitir  -> SO admin   (rota /live/emitir)
- 🔴 Ao Vivo     -> todos       (rota /live/sala/sala1)

## Depois
1. Substituir os 2 ficheiros.
2. Reiniciar o cliente e Ctrl+Shift+R.
3. Como admin aparece "📡 Transmitir"; clica -> permite a camara -> Iniciar.
4. Noutro dispositivo/aba clica em "🔴 Ao Vivo".

## Nota
A camara (getUserMedia) so funciona em HTTPS ou localhost.
